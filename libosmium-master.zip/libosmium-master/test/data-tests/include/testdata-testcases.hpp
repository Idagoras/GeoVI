#ifndef TESTDATA_TESTCASES_HPP
#define TESTDATA_TESTCASES_HPP

#include <catch.hpp>

#include <string>

extern std::string dirname;

#endif // TESTDATA_TESTCASES_HPP
